//zad 1

#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

int main() {
    string napis;
    cin>>napis;
    transform(napis.begin(),napis.end(),napis.begin(),::tolower);
    char min='z', max='a';
	for(int i=0; napis[i]!='\0';i++){
    		if(napis[i]>max)
    			max=napis[i];
    		if(napis[i]<min)
    			min=napis[i];
		}
	cout<<min<<" "<<max<<endl;
    
    return 0;
}
