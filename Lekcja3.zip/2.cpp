//zad 2 
#include <iostream>
#include <string.h>

using namespace std;

int main() {
    string napis("ala ma kota");
    string usun("kota");
    string dodaj="psa";
    size_t pos=napis.find(usun);

    while(pos!=string::npos) {
        napis.replace(pos,usun.length(), dodaj);
        pos=napis.find(usun,pos+dodaj.size());
    }
    cout << napis << endl;
    return 0;
}

