#include <iostream>
#include <string>
#include <fstream>

using namespace std;

int main()
{
	/*
    ofstream plik;
    plik.open ("/Users/student/Desktop/test.txt");
	plik << "test";
    plik.close();
    */
    
    fstream plik;
    plik.open ("/Users/student/Desktop/test.txt");
    string dane;
    
    while( getline( plik,dane) ) cout << dane;
    
    plik.close();
    
    return 0;
}
